# Command-And-Control-PHP

## Demo:  
https://user-images.githubusercontent.com/85383966/172116231-e8ba1f94-cb7a-4332-ae61-5125cbf19d5a.mp4


# WorkFlow:  
![workflow](https://user-images.githubusercontent.com/85383966/172119858-380f1671-bc75-440a-900e-869ca8a66b50.png) 


## GUI Preview  

Dashborad Page:  
<img width="953" alt="Dashborad" src="https://user-images.githubusercontent.com/85383966/172116572-b5a9575b-8eba-4ae7-891a-7027b7ad9690.png">


Victim Page:  
<img width="955" alt="victim" src="https://user-images.githubusercontent.com/85383966/172116509-528fc7b6-1a33-402f-976a-2030bfaed6a3.png">

Logs Page:  

<img width="948" alt="log" src="https://user-images.githubusercontent.com/85383966/172116621-74c70b12-9540-4039-87ba-90f5bfc989c9.png">


# DISCLAIMER
Use of this tool is limited only for education or legal work.    
It must not be used for purposes of study or legal work!

<?php
  header('Location: /landing/');
  exit();
?>
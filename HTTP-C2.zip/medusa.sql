-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 10 oct. 2022 à 00:55
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `medusa`
--

-- --------------------------------------------------------

--
-- Structure de la table `audits`
--

CREATE TABLE `audits` (
  `id` int(11) NOT NULL,
  `user_identifier` varchar(64) NOT NULL,
  `date` datetime NOT NULL,
  `severity` varchar(32) NOT NULL,
  `log` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `audits`
--

INSERT INTO `audits` (`id`, `user_identifier`, `date`, `severity`, `log`) VALUES
(1877, '127.0.0.1', '2022-10-09 18:16:16', 'WARNING', 'Password incorrect! the input is: Admin'),
(1878, '127.0.0.1', '2022-10-09 18:16:20', 'WARNING', 'Password incorrect! the input is: admin'),
(1879, '127.0.0.1', '2022-10-09 18:16:26', 'WARNING', 'Password incorrect! the input is: Password'),
(1880, '127.0.0.1', '2022-10-09 18:16:34', 'WARNING', 'Password incorrect! the input is: Admin'),
(1881, '127.0.0.1', '2022-10-09 19:10:43', 'WARNING', ' 127.0.0.1 Users Send Req with empty fields!'),
(1882, '127.0.0.1', '2022-10-09 19:13:17', 'WARNING', ' 127.0.0.1 Users Send Req with invalid password!'),
(1883, '127.0.0.1', '2022-10-09 19:14:04', 'WARNING', ' 127.0.0.1 Users Send Req with invalid password!'),
(1884, '127.0.0.1', '2022-10-09 19:16:29', 'WARNING', ' 127.0.0.1 Users Send Req with invalid password!'),
(1885, '127.0.0.1', '2022-10-09 20:47:49', 'WARNING', 'Password incorrect! the input is: admin'),
(1886, '127.0.0.1', '2022-10-09 20:49:32', 'WARNING', 'Password incorrect! the input is: NagatoroSh'),
(1887, '127.0.0.1', '2022-10-09 20:56:37', 'WARNING', 'Password incorrect! the input is: admin'),
(1888, '127.0.0.1', '2022-10-09 20:58:09', 'WARNING', 'Password incorrect! the input is: admin'),
(1889, '127.0.0.1', '2022-10-09 20:58:14', 'WARNING', 'Password incorrect! the input is: admin'),
(1890, '127.0.0.1', '2022-10-09 22:06:03', 'INFO', ' admin Login successfully'),
(1891, '127.0.0.1', '2022-10-09 22:06:39', 'INFO', ' admin Login successfully'),
(1893, '127.0.0.1', '2022-10-10 00:11:56', 'INFO', ' admin Login successfully'),
(1894, '127.0.0.1', '2022-10-10 00:12:11', 'INFO', 'password chagne successfuly'),
(1896, '127.0.0.1', '2022-10-10 00:12:36', 'INFO', ' admin Login successfully'),
(1897, '127.0.0.1', '2022-10-10 00:18:22', 'WARNING', 'Password incorrect! the input is: estroyer13@'),
(1898, '127.0.0.1', '2022-10-10 00:18:31', 'INFO', ' 1337Systemx86 Login successfully'),
(1900, '127.0.0.1', '2022-10-10 00:25:28', 'INFO', ' 1337Systemx86 Login successfully'),
(1901, '198375892096418', '2022-10-10 00:51:53', 'INFO', 'User Was connected! from ip: 127.0.0.1 hostname: DESKTOP-ISBMS7E '),
(1902, '198375892096418', '2022-10-10 00:51:53', 'INFO', 'New user / User conncted.'),
(1903, '198375892096418', '2022-10-10 00:51:53', 'COMMAND', ' First Regiser'),
(1904, '198375892096418', '2022-10-10 00:51:53', 'INFO', 'User take command whoami and challenge: 6846280226817'),
(1905, '198375892096418', '2022-10-10 00:53:33', 'INFO', 'User take command whoami and challenge: 6846280226817');

-- --------------------------------------------------------

--
-- Structure de la table `command`
--

CREATE TABLE `command` (
  `id` int(9) NOT NULL,
  `user_identifier` varchar(48) NOT NULL,
  `send_command` varchar(254) NOT NULL,
  `date` datetime NOT NULL,
  `challenge` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `command`
--

INSERT INTO `command` (`id`, `user_identifier`, `send_command`, `date`, `challenge`) VALUES
(1, '198375892096418', 'whoami', '2022-10-10 00:51:53', '6846280226817');

-- --------------------------------------------------------

--
-- Structure de la table `recive`
--

CREATE TABLE `recive` (
  `id` int(9) NOT NULL,
  `user_identifier` varchar(48) NOT NULL,
  `revice_output` varchar(8196) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `recive`
--

INSERT INTO `recive` (`id`, `user_identifier`, `revice_output`, `date`) VALUES
(1, '198375892096418', 'desktop-isbms7e\\driss\r\n', '2022-10-10 00:51:53'),
(2, '198375892096418', 'desktop-isbms7e\\driss\r\n', '2022-10-10 00:53:33');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `password`) VALUES
(1, '1337Systemx86', '$2y$10$kw/z9XOfVyT1FRqfbEPugeMHJkesHqEO9.cvP/jNbW83VuM2UajA2');

-- --------------------------------------------------------

--
-- Structure de la table `victims`
--

CREATE TABLE `victims` (
  `id` int(6) UNSIGNED NOT NULL,
  `HostName` varchar(30) DEFAULT NULL,
  `IP` varchar(30) DEFAULT NULL,
  `Active` varchar(30) DEFAULT NULL,
  `Last_Report` varchar(30) DEFAULT NULL,
  `OS` varchar(30) DEFAULT NULL,
  `UserName` varchar(30) DEFAULT NULL,
  `user_identifier` varchar(33) NOT NULL,
  `timezone` varchar(30) DEFAULT NULL,
  `uac` varchar(128) DEFAULT NULL,
  `admin_active` varchar(100) DEFAULT NULL,
  `isadmin` varchar(10) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `domain` varchar(50) DEFAULT NULL,
  `dir_location` varchar(50) DEFAULT NULL,
  `comments` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `victims`
--

INSERT INTO `victims` (`id`, `HostName`, `IP`, `Active`, `Last_Report`, `OS`, `UserName`, `user_identifier`, `timezone`, `uac`, `admin_active`, `isadmin`, `create_at`, `domain`, `dir_location`, `comments`) VALUES
(123, 'DESKTOP-ISBMS7E', '127.0.0.1', 'Yes', '2022-10-10 00:53:33', 'Windows-10-10.0.19044-SP0', 'Driss', '198375892096418', 'Europe/Paris', 'Is Enabled!', 'Is not active!', 'False', '2022-10-10 00:51:53', NULL, NULL, '');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `audits`
--
ALTER TABLE `audits`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `command`
--
ALTER TABLE `command`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `recive`
--
ALTER TABLE `recive`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `victims`
--
ALTER TABLE `victims`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_identifier` (`user_identifier`),
  ADD KEY `user_identifier_2` (`user_identifier`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `audits`
--
ALTER TABLE `audits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1906;

--
-- AUTO_INCREMENT pour la table `command`
--
ALTER TABLE `command`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `recive`
--
ALTER TABLE `recive`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `victims`
--
ALTER TABLE `victims`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
